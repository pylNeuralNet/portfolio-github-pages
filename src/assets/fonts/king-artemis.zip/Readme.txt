This font is a DEMO version of the font and the characters in it contain the standard version. Read the description below for more details.

By installing or using this font, you agree to the Product Use Agreement:

1. This font is for PERSONAL USE. No commercial use allowed!
2. If you want to use it for commercial purposes, you can download it via the following link and you will get the full version and complete characters:

https://timurtype.com/product/king-artemis/

3. If you don't mind, give me a cup of coffee to get even more excited!

Donate click here

https://paypal.me/timurtypestd

4. Please visit our store for more amazing fonts :

https://timurtype.com

5. For inquiries, you can contact me at: timurtype.studio@gmail.com

Thank you
Timurtype Studio

INDONESIAN VERSION:

1. Font demo ini hanya untuk penggunaan pribadi, tidak untuk komersial/yang menghasilkan profit atau keuntungan dari hasil menggunakan font ini. Baik itu untuk Pribadi, Agensi Desain Grafis, Youtube, Tv, Percetakan, Perusahaan dll. 
(APABILA ANDA MELANGGAR DAN MENGGUNAKAN TANPA MEMBELI LISENSI TERLEBIH DAHULU AKAN DIKENAKAN DENDA SEBESAR 10X LIPAT HARGA LISENSI SESUAI PENGGUNAAN).

2. Jika ingin menggunakan secara komersial silahkan membeli lisensi melalui link di bawah ini:

https://timurtype.com/product/king-artemis/

3. Untuk pertanyaan, Anda dapat menghubungi saya di: timurtype.studio@gmail.com

Terimakasih
Timurtype Studio